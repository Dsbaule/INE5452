Para execução das tarefas, entre na pasta correspondente e execute:
- make

As tarefas 2.3 e 2.4 foram implementadas por meio de um menu interno para seleção dentre os diferentes algorítmos