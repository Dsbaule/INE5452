Para execução das tarefas, entre na pasta correspondente e execute:
- make
	para execução padrão
- make test
	para execução das simulações