Para execução das tarefas, entre na pasta correspondente e execute:
- make